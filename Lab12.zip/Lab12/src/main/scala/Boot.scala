
import com.amazonaws.auth.{AWSStaticCredentialsProvider, BasicAWSCredentials}
import com.amazonaws.regions.Regions
import com.amazonaws.services.s3.{AmazonS3, AmazonS3ClientBuilder}


import java.io.File
import java.nio.file.{Files, StandardCopyOption}

import akka.actor.ActorSystem
import akka.pattern.ask
import akka.http.scaladsl.Http
import akka.http.scaladsl.server.Directives.{delete, put, _}
import akka.http.scaladsl.marshallers.sprayjson.SprayJsonSupport._
import akka.stream.{ActorMaterializer, Materializer}
import akka.util.Timeout
import com.amazonaws.services.s3.model.{GetObjectRequest, ListObjectsRequest, ListObjectsV2Request, ObjectMetadata, PutObjectRequest}
import org.slf4j.LoggerFactory

import scala.concurrent.duration._


import akka.actor.ActorSystem
import akka.pattern.ask
import akka.http.scaladsl.Http
import akka.http.scaladsl.server.Directives.{delete, put, _}
import akka.http.scaladsl.marshallers.sprayjson.SprayJsonSupport._
import akka.stream.{ActorMaterializer, Materializer}
import akka.util.Timeout

import scala.concurrent.duration._
import scala.concurrent.ExecutionContextExecutor

object Boot extends App with SprayJsonSerializer {
  implicit val system: ActorSystem = ActorSystem("photo-service")
  implicit val materializer: Materializer = ActorMaterializer()

  implicit val ec: ExecutionContextExecutor = system.dispatcher
  implicit val timeout: Timeout = Timeout(10.seconds)

  val log = LoggerFactory.getLogger("Boot")

  val credentials = new BasicAWSCredentials(
    "AKIAQJR62HKNUWSILCUZ",
    "+H7kl8HIEOAR99g7fQKfR9iYad9CR87G2RqmiytH"
  )
  val clientRegion: Regions = Regions.EU_CENTRAL_1

  val client: AmazonS3 = AmazonS3ClientBuilder.standard()
    .withCredentials(new AWSStaticCredentialsProvider(credentials))
    .withRegion(clientRegion)
    .build()

  private val photoManager = system.actorOf(PhotoManager.props(client), "photo-manager")




  val bucketName = "lab12-photo-service-kbtu"

  if (client.doesBucketExistV2(bucketName)) {
    log.info("Bucket exists")
  }
  else {
    client.createBucket(bucketName)
    log.info("Bucket added")
  }

  private val route =
    pathPrefix("photos") {
      path(Segment) { id =>
        get {
          complete {
            (photoManager ? PhotoManager.GetPhoto(id)).mapTo[Either[ErrorResponse, SuccessfulResponse]]
          }
        }
      }
    }

  Http().bindAndHandle(route, "0.0.0.0", 8080)
  log.info("Listening on port 8080...")

}