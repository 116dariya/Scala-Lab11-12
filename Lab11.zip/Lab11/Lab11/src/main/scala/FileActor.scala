
import java.io.{File, InputStream}

import akka.actor.{Actor, ActorLogging, Props}
import com.amazonaws.services.s3.AmazonS3
import java.nio.file.{Files, Path, Paths, StandardCopyOption}

import scala.util.{Failure, Success, Try}
import com.amazonaws.services.s3.model.{GetObjectRequest, ObjectMetadata, PutObjectRequest}

object FileActor {

  case class GetObject(bucket: String, objectKey: String)

  case class CreateObject(bucket: String, filename: String)
  def props(client: AmazonS3, bucketName: String) = Props(new FileActor(client, bucketName))
}

class FileActor(client: AmazonS3, bucketName: String) extends Actor with ActorLogging {

  import FileActor._
  val pathS3 = "./src/main/resources/s3"


  override def receive: Receive = {
    case GetObject(bucket, objectKey) =>
      if (client.doesObjectExist(bucket, objectKey)) {
        Try(getObject(bucket, objectKey)) match {
          case Success(_) =>
            sender() ! Right(200, s"Object with key $objectKey successfully downloaded")
          case Failure(_) =>
            sender() ! Left(500, s"Error while downloading object with key $objectKey")
        }
      } else {
        sender() ! Left(404, s"Object does not exist")
      }
    case CreateObject(bucket, filename) => {
//      val file: File = new File(s"${pathS3}/$filename")
      val file: File = new File("/Users/dariyamukhatova/IdeaProjects/Lab11/src/main/resources/s3/nice/file/abc.txt")


      if (file.exists()) {
        val request: PutObjectRequest = new PutObjectRequest(
          bucket,
          filename,
          file)

        log.info("request: {}", request == null)
//        log.info(client.getBucketLocation(task1Bucket))
        val metadata = new ObjectMetadata()
        metadata.setContentType("plain/text")
        metadata.addUserMetadata("user-type", "customer")
        request.setMetadata(metadata)

        Try(client.putObject(request)) match {
          case Success(_) =>
            sender() ! Right(SuccessfulResponse(200, s"Object with key $filename successfully uploaded"))
          case Failure(error) =>
            log.error(error, "Failed to put to bucket: ")
            sender() ! Left(ErrorResponse(500, s"Error while uploading object with key $filename"))
        }
//        client.putObject(request)
      } else {
        sender() ! Left(404, s"Object cannot be found")
      }
    }
  }

  private def getObject(bucket: String, objectKey: String): Unit = {
    val fullObject = client.getObject(new GetObjectRequest(bucket, objectKey))
    val objectStream = fullObject.getObjectContent

    val file = new File(s"${pathS3}/$objectKey")
    if (!file.exists()) file.mkdirs()
    file.createNewFile()

    Files.copy(objectStream, file.toPath, StandardCopyOption.REPLACE_EXISTING)
    objectStream.close()
  }
}
