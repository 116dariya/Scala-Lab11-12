
import com.amazonaws.auth.{AWSStaticCredentialsProvider, BasicAWSCredentials}
import com.amazonaws.regions.Regions
import com.amazonaws.services.s3.{AmazonS3, AmazonS3ClientBuilder}


import java.io.File
import java.nio.file.{Files, StandardCopyOption}

import akka.actor.ActorSystem
import akka.pattern.ask
import akka.http.scaladsl.Http
import akka.http.scaladsl.server.Directives.{delete, put, _}
import akka.http.scaladsl.marshallers.sprayjson.SprayJsonSupport._
import akka.stream.{ActorMaterializer, Materializer}
import akka.util.Timeout
import com.amazonaws.services.s3.model.{GetObjectRequest, ListObjectsRequest, ListObjectsV2Request, ObjectMetadata, PutObjectRequest}
import org.slf4j.LoggerFactory

import scala.concurrent.duration._


object Boot extends App with SprayJsonSerializer  {


  implicit val system: ActorSystem = ActorSystem("file-service")
  implicit val materializer: ActorMaterializer = ActorMaterializer()



  implicit val timeout: Timeout = Timeout(10.seconds)


  val log = LoggerFactory.getLogger("Boot")

  val clientRegion: Regions = Regions.EU_CENTRAL_1

  val credentials = new BasicAWSCredentials(
    "AKIAQJR62HKNUWSILCUZ",
    "+H7kl8HIEOAR99g7fQKfR9iYad9CR87G2RqmiytH"
  )

  val client: AmazonS3 = AmazonS3ClientBuilder.standard()
    .withCredentials(new AWSStaticCredentialsProvider(credentials))
    .withRegion(clientRegion)
    .build()

  val task1Bucket = "danara-godoga-horoshaya-task1"
  val task2Bucket = "danara-godoga-horoshaya-task1-task2"
  val pathIn = "./src/main/resources/in"
  val pathOut = "./src/main/resources/out"

  if (client.doesBucketExistV2(task1Bucket)) {
    log.info("Bucket1 exists")
  }
  else {
    client.createBucket(task1Bucket)
    log.info("Bucket1 added")
  }
  if (client.doesBucketExistV2(task2Bucket)) {
    log.info("Bucket2 exists")
  }
  else {
    client.createBucket(task2Bucket)
    log.info("Bucket2 added")
  }

  val worker = system.actorOf(FileActor.props(client, task1Bucket))


  val route =
    path("health") {
      get {
        complete {
          "OK"
        }
      }
    } ~
      pathPrefix("lab11") {
        path("file") {
          concat(
            get {
              parameters("filename".as[String]) { filename =>
                complete {
                  (worker ? FileActor.GetObject(task1Bucket, filename)).mapTo[Either[ErrorResponse, SuccessfulResponse]]
                }
              }
            },
            post {
              entity(as[Path]) { path =>
                complete {
                  (worker ? FileActor.CreateObject(task1Bucket, path.filename)).mapTo[Either[ErrorResponse, SuccessfulResponse]]
                }
              }
            })
        } ~
          pathPrefix("task2") {
            path("in") {
              get {
                complete {
                  downloadIn()
                  "DownloadIn"
                }
              }
            } ~
              path("out") {
                get {
                  complete {
                    uploadOut(new File(pathOut))
                    "UploadOut"
                  }
                }
              }
          }
      }




  val bindingFuture = Http().bindAndHandle(route, "0.0.0.0", 8080)
  log.info("Listening on port 8080...")

  private def uploadOut(root: File): Unit = {
    val files = root.listFiles().filter(!_.getName.equals(".DS_Store"))
    for (file <- files) {
      if (file.isDirectory) uploadOut(new File(file.getPath))
      else uploadFile(file)
    }
  }

  private def uploadFile(file: File): Unit = {
    val request = new PutObjectRequest(
      task2Bucket,
      file.getPath.replace(s"${pathOut}/", ""),
      file)
    val metadata = new ObjectMetadata()
    metadata.setContentType("plain/text")
    metadata.addUserMetadata("user-type", "customer")
    request.setMetadata(metadata)
    client.putObject(request)
  }

  private def downloadIn(): Unit = {
    val request = new ListObjectsV2Request().withBucketName(task2Bucket)
    val objectsList = client.listObjectsV2(request)
    objectsList.getObjectSummaries.forEach(obj => createFile(obj.getKey))
  }

  private def createFile(objectKey: String): Unit = {
    val fullObject = client.getObject(new GetObjectRequest(task2Bucket, objectKey))
    val objectStream = fullObject.getObjectContent

    val file = new File(s"${pathIn}/$objectKey")
    if (!file.isDirectory) {
      if (!file.exists()) file.mkdirs()
      file.createNewFile()

      Files.copy(objectStream, file.toPath, StandardCopyOption.REPLACE_EXISTING)
    }
    objectStream.close()
  }

}